﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Colosoft.WebControls.Providers {

    /// <summary>
    /// Summary description for ProviderUtil
    /// </summary>
    internal static class ProviderUtil {

        #region Static Methods //////////////////////////////////////////////////////////

        /// <summary>
        /// 
        /// </summary>
        public static void EnsureDataFoler() {

            if (HttpContext.Current != null) {
                string folder = HttpContext.Current.Server.MapPath("~/App_Data/");
                if (!Directory.Exists(folder)) {
                    Directory.CreateDirectory(folder);
                }
            }
        }

        /// <summary>
        /// Gets the config value.
        /// </summary>
        /// <param name="configValue">The config value.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        public static string GetConfigValue(string configValue, string defaultValue) {
            return (String.IsNullOrEmpty(configValue)) ? defaultValue : configValue;
        }
        #endregion
    }
}