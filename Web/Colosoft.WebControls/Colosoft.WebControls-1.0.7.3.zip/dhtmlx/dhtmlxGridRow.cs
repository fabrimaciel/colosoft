﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Colosoft.WebControls.dhtmlx
{
    /// <summary>
    /// Representa uma linha do grid.
    /// </summary>
    public class dhtmlxGridRow : IEnumerable<dhtmlxGridCell>
    {
        #region Variáveis Locais

        private dhtmlxGridSource _gridSource;

        private dhtmlxGridCell[] _cells;

        private string _ID;

        private bool _selected;

        private string _style;

        private string _cssClass;

        private dhtmlxAttributeCollection _attributes;

        #endregion

        #region Propriedades

        /// <summary>
        /// Fonte da grid relacionada com a linha.
        /// </summary>
        public dhtmlxGridSource GridSource
        {
            get { return _gridSource; }
        }

        /// <summary>
        /// Identificador da linha.
        /// </summary>
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        /// <summary>
        /// Identificador se a linha está selecionada.
        /// </summary>
        public bool Selected
        {
            get { return _selected; }
            set { _selected = value; }
        }

        /// <summary>
        /// Definição de estilo CSS.
        /// </summary>
        public string Style
        {
            get { return _style; }
            set { _style = value; }
        }

        /// <summary>
        /// Nome do CSS class relacionada com a célula.
        /// </summary>
        public string CssClass
        {
            get { return _cssClass; }
            set { _cssClass = value; }
        }

        /// <summary>
        /// Atributos customizados da linha.
        /// </summary>
        public dhtmlxAttributeCollection Attributes
        {
            get { return _attributes; }
        }


        #endregion

        #region Construtor

        internal dhtmlxGridRow(dhtmlxGridSource gridSource)
        {
            _gridSource = gridSource;

            // Instancia o vetor onde serão armazenadas as células da linha.
            _cells = new dhtmlxGridCell[gridSource.Columns.Count];

            _attributes = new dhtmlxAttributeCollection();
        }

        #endregion

        #region Métodos Internos

        /// <summary>
        /// Carrega os dados da linha.
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="parent"></param>
        /// <param name="type">Tipo da fonte do grid.</param>
        internal void LoadElement(XmlDocument doc, XmlElement parent, dhtmlxGridSourceType type)
        {
            XmlElement row = doc.CreateElement(type == dhtmlxGridSourceType.Xml ? "row" : "tr");

            if (!string.IsNullOrEmpty(_ID))
                row.SetAttribute("id", _ID);

            if (_selected)
                row.SetAttribute("selected", "1");

            if (!string.IsNullOrEmpty(_style))
                row.SetAttribute("style", _style);

            if (!string.IsNullOrEmpty(_cssClass))
                row.SetAttribute("class", _cssClass);

            _attributes.LoadAttributes(row);

            foreach (dhtmlxGridCell cell in _cells)
                cell.LoadElement(doc, row, type);

            parent.AppendChild(row);
        }

        #endregion

        #region Operadores Sobreescritos

        /// <summary>
        /// Define e recupera o valor da célula.
        /// </summary>
        /// <param name="index">Index da coluna.</param>
        /// <returns>Valor da célula.</returns>
        public string this[int index]
        {
            get 
            {
                if (_cells[index] == null) return null;
                else return _cells[index].Value; 
            }
            set 
            {
                if (value != null && _cells[index] == null)
                    _cells[index] = new dhtmlxGridCell();

                else if (value == null && _cells[index] == null)
                    return;
               
               _cells[index].Value = value; 
            }
        }

        /// <summary>
        /// Define e recupera o valor da célula.
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>Valor da célula.</returns>
        public string this[string columnName]
        {
            get
            {
                for(int i=0; i<GridSource.Columns.Count; i++)
                    if (GridSource.Columns[i].ColumnName == columnName)
                        return this[i];

                throw new KeyNotFoundException(String.Format("Column name {0} not found.", columnName));
            }

            set
            {
                for (int i=0; i < GridSource.Columns.Count; i++)
                    if (GridSource.Columns[i].ColumnName == columnName)
                    {
                        this[i] = value;
                        return;
                    }

                throw new KeyNotFoundException(String.Format("Column name {0} not found.", columnName));
            }
        }

        #endregion

        #region IEnumerable<dhtmlxGridCell> Members

        public IEnumerator<dhtmlxGridCell> GetEnumerator()
        {
            return (IEnumerator<dhtmlxGridCell>)_cells.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return _cells.GetEnumerator();
        }

        #endregion
    }
}
