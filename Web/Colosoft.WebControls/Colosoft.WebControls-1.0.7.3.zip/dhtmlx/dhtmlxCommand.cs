﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Colosoft.WebControls.dhtmlx
{
    /// <summary>
    /// Representa as informações de um comando a ser
    /// chamado por um componente dhtmlx.
    /// </summary>
    public class dhtmlxCommand
    {
        #region Variáveis Locais

        private string _commandName;

        private List<string> _parameters = new List<string>();

        #endregion

        #region Propriedades

        /// <summary>
        /// Nome do comando.
        /// </summary>
        public string CommandName
        {
            get { return _commandName; }
            set { _commandName = value; }
        }

        /// <summary>
        /// Parametros do comando.
        /// </summary>
        public IList<string> Parameters
        {
            get { return _parameters; }
        }

        #endregion

        #region Construtor

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        /// <param name="commandName">Nome do comando.</param>
        /// <param name="parameters">Parametros do comando.</param>
        public dhtmlxCommand(string commandName, params string[] parameters)
        {
            _commandName = commandName;
            _parameters.AddRange(parameters);
        }

        #endregion

        #region Métodos Internos

        internal void LoadElement(XmlDocument doc, XmlElement parent)
        {
            // Constrói a tag do comando
            XmlElement cmd = doc.CreateElement("call");
            cmd.SetAttribute("command", _commandName);

            foreach (string p in _parameters)
            {
                // Constrói a tag do parametro do comando
                XmlElement param = doc.CreateElement("param");
                param.InnerText = p;
                cmd.AppendChild(param);
            }

            parent.AppendChild(cmd);
        }

        #endregion
    }
}
