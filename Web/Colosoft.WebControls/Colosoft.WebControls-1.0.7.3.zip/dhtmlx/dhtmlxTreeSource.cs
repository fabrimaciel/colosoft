﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace Colosoft.WebControls.dhtmlx
{
    #region Delegates

    /// <summary>
    /// Representa o método acionado quando for solicitado os itens relacionados ao
    /// item com o ID passado.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="id">Identificador do item pai.</param>
    /// <returns>Lista dos itens as serem carregados.</returns>
    public delegate IList<dhtmlxTreeItem> LoadingTreeItems(object sender, string id);

    #endregion

    public class dhtmlxTreeSource
    {
        #region Variáveis Locais

        private string _ID;

        private string _imagePath;

        private bool _enabledCheckBox;

        private bool _enabledDragAndDrop;

        /// <summary>
        /// Lista dos itens da Tree.
        /// </summary>
        private List<dhtmlxTreeItem> _items = new List<dhtmlxTreeItem>();

        #endregion

        #region Eventos

        public event LoadingTreeItems LoadingItems;

        #endregion

        #region Propriedades

        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public string ImagePath
        {
            get { return _imagePath; }
            set { _imagePath = value; }
        }

        public bool EnabledCheckBox
        {
            get { return _enabledCheckBox; }
            set { _enabledCheckBox = value; }
        }

        public bool EnabledDragAndDrop
        {
            get { return _enabledDragAndDrop; }
            set { _enabledDragAndDrop = value; }
        }

        /// <summary>
        /// Lista dos itens da Tree.
        /// </summary>
        public List<dhtmlxTreeItem> Items
        {
            get { return _items; }
        }

        #endregion

        #region Construtores

        public dhtmlxTreeSource()
        {
            _ID = Guid.NewGuid().ToString();
        }

        public dhtmlxTreeSource(string ID)
        {
            _ID = ID;
        }

        #endregion

        #region Métodos Públicos

        /// <summary>
        /// Salva os dados da arvore no stream.
        /// </summary>
        /// <param name="outStream"></param>
        public void SaveSource(Stream outStream)
        {
            XmlDocument doc = new XmlDocument();

            XmlElement tree = doc.CreateElement("tree");
            tree.SetAttribute("id", _ID);

            foreach (dhtmlxTreeItem item in _items)
            {
                item.LoadElement(doc, tree);
            }

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Reset();
            settings.Encoding = Encoding.GetEncoding("iso-8859-1");

            XmlWriter writer = XmlWriter.Create(outStream, settings);
            doc.AppendChild(tree);

            doc.Save(writer);
        }

        public void SaveSource(Stream outStream, string node)
        {
            XmlDocument doc = new XmlDocument();

            XmlElement tree = doc.CreateElement("tree");
            tree.SetAttribute("id", node);

            IList<dhtmlxTreeItem> loadItens = null;

            if (LoadingItems != null)
            {
                loadItens = LoadingItems(this, node);
            }

            if (loadItens != null)
            {

                foreach(dhtmlxTreeItem item in loadItens)
                {
                    item.LoadElement(doc, tree);
                }
            }

            doc.AppendChild(tree);

            doc.Save(outStream);
            
        }

        #endregion
    }
}
