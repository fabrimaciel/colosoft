﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Xml;

namespace Colosoft.WebControls.dhtmlx
{
    public class dhtmlxAttributeCollection : IEnumerable
    {
        #region Variáveis Locais

        private System.Web.UI.StateBag _stateBag;

        #endregion

        #region Propriedades

        /// <summary>
        /// Número de atributos na coleção.
        /// </summary>
        public int Count
        {
            get { return _stateBag.Count; }
        }

        /// <summary>
        /// Chaves da coleção.
        /// </summary>
        public System.Collections.ICollection Keys
        {
            get { return _stateBag.Keys; }
        }

        /// <summary>
        /// Recupera o valor do atributo.
        /// </summary>
        /// <param name="key">Chave do atributo.</param>
        /// <returns>Valor do atributo.</returns>
        public string this[string key]
        {
            get { return (string)_stateBag[key]; }
        }

        #endregion

        #region Construtor

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        public dhtmlxAttributeCollection()
        {
            _stateBag = new System.Web.UI.StateBag(true);
        }

        #endregion

        #region Métodos Públicos

        /// <summary>
        /// Adiciona o atributo na coleção.
        /// </summary>
        /// <param name="key">Nome do atributo.</param>
        /// <param name="value">Valor do atributo.</param>
        public void Add(string key, string value)
        {
            _stateBag.Add(key, value);
        }

        /// <summary>
        /// Remove o atributo da coleção.
        /// </summary>
        /// <param name="key">Nome do atributo.</param>
        public void Remove(string key)
        {
            _stateBag.Remove(key);
        }

        #endregion

        #region Métodos Internos

        /// <summary>
        /// Carrega os atributos no elemento XML.
        /// </summary>
        /// <param name="element"></param>
        internal void LoadAttributes(XmlElement element)
        {
            foreach (object obj in _stateBag)
            {
                System.Collections.DictionaryEntry entry = (System.Collections.DictionaryEntry)obj;
                element.SetAttribute((string)entry.Key, (string)((System.Web.UI.StateItem)entry.Value).Value);
            }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return _stateBag.GetEnumerator();
        }

        #endregion
    }
}
