﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Colosoft.WebControls.dhtmlx
{
    /// <summary>
    /// Representa as opções que podem ser atribuidas para uma coluna da grid.
    /// </summary>
    public class dhtmlxGridColumnOption
    {
        #region Variáveis Locais

        private string _value;

        private string _text;

        #endregion

        #region Propriedades

        /// <summary>
        /// Valor da opção.
        /// </summary>
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        /// <summary>
        /// Texto da opção.
        /// </summary>
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        #endregion

        #region Construtor

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        /// <param name="value">Valor da opção.</param>
        /// <param name="text">Texto da opção.</param>
        public dhtmlxGridColumnOption(string value, string text)
        {
            _value = value;
            _text = text;
        }

        #endregion

        #region Métodos Internos

        /// <summary>
        /// Carrega os dados do elemento.
        /// </summary>
        /// <param name="doc">Documento que está sendo trabalhado.</param>
        /// <param name="parent">Elemento pai o elemento deve ser inserido.</param>
        internal void LoadElement(XmlDocument doc, XmlElement parent)
        {
            XmlElement option = doc.CreateElement("option");

            option.SetAttribute("value", _value);
            option.InnerText = _text;

            parent.AppendChild(option);
        }

        #endregion
    }
}
