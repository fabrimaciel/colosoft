﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

namespace Colosoft.WebControls.dhtmlx
{
    public class dhtmlxGrid : WebControl
    {
        #region Variáveis Locais

        private dhtmlxGridSource _source;

        #endregion

        #region Propriedades

        /// <summary>
        /// Fonte de dados do grid.
        /// </summary>
        public dhtmlxGridSource Source
        {
            get { return _source; }
            set { _source = value; }
        }

        #endregion
    }
}
