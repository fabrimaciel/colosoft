﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.dhtmlx
{
    /// <summary>
    /// Representa o cabeçalho do grid.
    /// </summary>
    public class dhtmlxGridHeader
    {
        
    }
}
