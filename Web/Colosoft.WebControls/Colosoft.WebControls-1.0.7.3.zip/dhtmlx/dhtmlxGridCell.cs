﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Colosoft.WebControls.dhtmlx
{
    /// <summary>
    /// Representa uma celula do grid.
    /// </summary>
    public class dhtmlxGridCell
    {
        #region Variáveis Locais

        private dhtmlxeXcellType _cellType;

        private string _value;

        private string _style;

        #endregion

        #region Propriedades

        /// <summary>
        /// Tipo da célula.
        /// </summary>
        public dhtmlxeXcellType CellType
        {
            get { return _cellType; }
            set { _cellType = value; }
        }

        /// <summary>
        /// Valor da célula.
        /// </summary>
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        /// <summary>
        /// Definição de estilo CSS.
        /// </summary>
        public string Style
        {
            get { return _style; }
            set { _style = value; }
        }

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        public dhtmlxGridCell()
            : this(dhtmlxeXcellType.Undefined, null)
        {
        }

        /// <summary>
        /// Construtor completo.
        /// </summary>
        /// <param name="cellType">Tipo da célula.</param>
        /// <param name="value">Valor da célula.</param>
        public dhtmlxGridCell(dhtmlxeXcellType cellType, string value)
        {
            _cellType = cellType;
            _value = value;
        }

        #endregion

        #region Métodos Internos

        /// <summary>
        /// Carregas os dados da célula no elemento pai.
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="parent"></param>
        /// <param name="type">Tipo da fonte do grid.</param>
        internal void LoadElement(XmlDocument doc, XmlElement parent, dhtmlxGridSourceType type)
        {
            XmlElement cell = doc.CreateElement(type == dhtmlxGridSourceType.Xml ? "cell" : "td");

            if (_cellType != dhtmlxeXcellType.Undefined)
                cell.SetAttribute("type", dhtmlxUtils.ConverteXcellType(_cellType));

            if (!string.IsNullOrEmpty(_style))
                cell.SetAttribute("style", _style);

            cell.InnerText = _value;

            parent.AppendChild(cell);
        }

        #endregion
    }
}
