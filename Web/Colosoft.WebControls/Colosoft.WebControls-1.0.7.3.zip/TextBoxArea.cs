﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web;

namespace Colosoft.WebControls
{
    [AspNetHostingPermission(System.Security.Permissions.SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class TextBoxArea : TextBox
    {
        protected override void OnInit(EventArgs e)
        {
            // Ensure underlying Initialisation takes place
            base.OnInit(e);

            // Configure TextArea support
            // The System.Web.UI.WebControls.TextBox does not
            // honour the "MaxLength" attribute when the
            // "Multiline" textmode is selected.
            if ((this.TextMode == TextBoxMode.MultiLine) && (this.MaxLength > 0))
            {
                // If we haven't already, include the supporting
                // script that limits the content of textareas.
                this.Page.ClientScript.RegisterClientScriptResource(typeof(TextBoxArea), "Colosoft.WebControls.Resources.textArea.js");

                // Add an expando attribute to the rendered control which sets
                // its maximum length (using the MaxLength Attribute)
                // Using RegisterExpandoAttribute maintains XHTML compliance on
                // the rendered page.
                this.Attributes.Add("exMaxLen", this.MaxLength.ToString());

                // Now bind the onkeydown, oninput and onpaste events to
                // script that we'll inject in the parent page.
                this.Attributes.Add("onkeydown", "javascript:return LimitInput(this, event);");
                this.Attributes.Add("oninput", "javascript:return LimitInput(this, event);");
                this.Attributes.Add("onpaste", "javascript:return LimitPaste(this, event);");
            }
        }
    }
}
