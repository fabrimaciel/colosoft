﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Colosoft.WebControls")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Colosoft")]
[assembly: AssemblyProduct("Colosoft.WebControls")]
[assembly: AssemblyCopyright("Copyright © Colosoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: System.Web.UI.WebResource("Colosoft.WebControls.Resources.textArea.js", "application/x-javascript")]
[assembly: System.Web.UI.WebResource("Colosoft.WebControls.Resources.simpleTabControl.js", "application/x-javascript")]
[assembly: System.Web.UI.WebResource("Colosoft.WebControls.Resources.SlideShow.slide.js", "application/x-javascript")]


#region Scripts & Stylesheet
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.PropertyGrid.css", "text/css", PerformSubstitution = true)]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.jquery.pack.js", "application/x-javascript")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.jquery.debug.js", "application/x-javascript")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.PropertyGrid.js", "application/x-javascript", PerformSubstitution = true)]
#endregion Scripts & Stylesheet

#region Images
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.active.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.collapse.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.collapse2.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.down.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.expand.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.expand2.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.grey-closed.png", "image/png")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.grey-open.png", "image/png")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.help.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.helpoff.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.info.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.lock.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.off.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.on.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.pg.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.refresh.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.unfresh.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.up.gif", "image/gif")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.white-closed.png", "image/png")]
[assembly: WebResource("Colosoft.WebControls.Resources.PropertyGrid.white-open.png", "image/png")]
#endregion Images

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ac5b14d5-49d3-438d-8ab1-3087d1fe1434")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.7.*")]
[assembly: AssemblyFileVersion("1.0.7.3")]
