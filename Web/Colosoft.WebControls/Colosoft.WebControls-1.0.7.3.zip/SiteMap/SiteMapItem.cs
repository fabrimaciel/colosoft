﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.SiteMap
{
    public enum Frenquently
    {
        Always,
        Hourly,
        Daily,
        Weekly,
        Monthly,
        Yearly,
        Never
    }

    /// <summary>
    /// Item do mapa do site.
    /// </summary>
    public class SiteMapItem
    {
        #region Variaveis Locais

        private string _localization;
        private DateTime? _lastModification;
        private Frenquently? _changeFrequently;
        private float _priority = 0.5f;

        #endregion

        #region Propriedades

        /// <summary>
        /// URL of the page. This URL must begin with the protocol (such as http) and end with a trailing slash, 
        /// if your web server requires it. This value must be less than 2,048 characters.
        /// </summary>
        public string Localization
        {
            get { return _localization; }
            set 
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Localization");

                _localization = value; 
            }
        }

        /// <summary>
        /// The date of last modification of the file. This date should be in  W3C Datetime format. 
        /// This format allows you to omit the time portion, if desired, and use YYYY-MM-DD.
        /// Note that this tag is separate from the If-Modified-Since (304) header the server can 
        /// return, and search engines may use the information from both sources differently.
        /// </summary>
        public DateTime? LastModification
        {
            get { return _lastModification; }
            set { _lastModification = value; }
        }

        /// <summary>
        /// How frequently the page is likely to change. This value provides general 
        /// information to search engines and may not correlate exactly to how often they crawl the page.
        /// </summary>
        public Frenquently? ChangeFrequently
        {
            get { return _changeFrequently; }
            set { _changeFrequently = value; }
        }

        /// <summary>
        /// The priority of this URL relative to other URLs on your site. 
        /// Valid values range from 0.0 to 1.0. This value does not affect 
        /// how your pages are compared to pages on other sites—it only lets 
        /// the search engines know which pages you deem most important for the crawlers.
        /// </summary>
        public float Priority
        {
            get { return _priority; }
            set { _priority = value; }
        }

        #endregion

        public SiteMapItem(string localization)
        {
            Localization = localization;
        }
    }
}
