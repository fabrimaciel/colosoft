﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace Colosoft.WebControls.SiteMap
{
    public class SiteMapFile
    {
        #region Variaveis Locais

        private List<SiteMapItem> _items = new List<SiteMapItem>();

        #endregion

        #region Propriedades

        /// <summary>
        /// Itens do mapa do site.
        /// </summary>
        public List<SiteMapItem> Items
        {
            get { return _items; }
        }

        #endregion

        #region Metodos Publicos

        /// <summary>
        /// Controi com base nos items o arquivo Sitemap.
        /// </summary>
        /// <param name="outStream"></param>
        public void Build(Stream outStream)
        {
            XmlDocument doc = new XmlDocument();

            XmlElement urlset = doc.CreateElement("urlset");

            urlset.SetAttribute("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9");

            foreach (SiteMapItem item in Items)
            {
                XmlElement xItem = doc.CreateElement("url");
                XmlElement loc = doc.CreateElement("loc");

                loc.InnerText = item.Localization;
                xItem.AppendChild(loc);

                if (item.LastModification != null)
                {
                    XmlElement lastmod = doc.CreateElement("lastmod");
                    lastmod.InnerText = item.LastModification.GetValueOrDefault().ToString("yyyy-MM-dd");
                    xItem.AppendChild(lastmod);
                }

                if (item.ChangeFrequently != null)
                {
                    XmlElement changefreq = doc.CreateElement("changefreq");
                    changefreq.InnerText = item.ChangeFrequently.ToString().ToLower();
                    xItem.AppendChild(changefreq);
                }

                XmlElement priority = doc.CreateElement("priority");
                priority.InnerText = item.Priority.ToString("0.0");
                xItem.AppendChild(priority);

                urlset.AppendChild(xItem);

            }

            doc.AppendChild(urlset);

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Reset();
            settings.Encoding = Encoding.GetEncoding("iso-8859-1");

            using(XmlWriter writer = XmlWriter.Create(outStream, settings))
                doc.Save(writer);
        }

        #endregion
    }
}
