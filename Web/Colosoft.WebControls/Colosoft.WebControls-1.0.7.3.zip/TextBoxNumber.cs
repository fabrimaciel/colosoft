﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

namespace Colosoft.WebControls
{
    public class TextBoxNumber : TextBox
    {
        private string _culture = "en-US";

        public string Culture
        {
            get { return _culture; }
            set { _culture = value; }
        }
        /// <summary>
        /// Returns script used to validate numbers
        /// </summary>
        /// <returns></returns>
        protected string GetNumberValidatorScript()
        {

            //#region BUILDS NUMERIC VALIDATION SCRIPT ONKEYPRESS
            string _str;
            _str = "<script> ";
            _str += @" function FilterNumeric(){";
            _str += @" var re; ";
            _str += @"var ch=String.fromCharCode(event.keyCode);";
            _str += @"if (event.keyCode<32)";
            _str += @"{";
            _str += @"return;";
            _str += @"};";

            _str += @"if( (event.keyCode<=57)&&(event.keyCode>=48))";
            _str += @"{";
            _str += @"if (!event.shiftKey)";
            _str += @"{";
            _str += @"return;";
            _str += @"}";
            _str += @"}";
            _str += @"if ((ch=='-') ||(ch=='.') || (ch==','))";
            _str += @"{";
            _str += @"return;";
            _str += @"}";
            _str += @"event.returnValue=false;";
            _str += "}</script>";

            return _str;

            //			this.Page.RegisterClientScriptBlock ("FilterNumeric",_str);//" <script> function FilterNumeric(){var re; alert (event.keyCode) ;if (event.keyCode<48){event.returnValue=false;}if (event.keyCode>57){	if (event.keyCode!=190){ event.returnValue=false;}}}</script>" );
            //			#endregion 

        }

        protected RegularExpressionValidator BuildNumberValidator(string iIDArg, string strErrArg)
        {

            string _strSeperator;

            //Retrieve Decimal symbol used in OS
            _strSeperator = System.Globalization.CultureInfo.GetCultureInfo(_culture).NumberFormat.NumberDecimalSeparator;

            //Building expresion validator
            RegularExpressionValidator rVal = new RegularExpressionValidator();

            //Set id of control to be validated 
            rVal.ControlToValidate = iIDArg;

            rVal.ValidationExpression = @"(^[-]?[1-9]\d+$)|(^[-]?[1-9]$)|(^0$)|(^[-]?[1-9]\d+\" + _strSeperator + @"\d$)|(^[-]?[0-9]\" + _strSeperator + @"\d$)";

            rVal.Font.Bold = true;
            rVal.Font.Name = "Arial";
            rVal.ErrorMessage = strErrArg;
            rVal.ToolTip = "NNNNN.N";
            rVal.Display = ValidatorDisplay.None;
            rVal.EnableViewState = false;
            rVal.Visible = true;
            return rVal;

        }

        protected override void OnInit(EventArgs e)
        {
            string _strSeperator;

            //Retrieve Decimal symbol used in OS
            _strSeperator = System.Globalization.CultureInfo.GetCultureInfo(_culture).NumberFormat.NumberDecimalSeparator;

            if (!Page.ClientScript.IsClientScriptBlockRegistered("FilterNumeric"))
                Page.ClientScript.RegisterClientScriptBlock(typeof(string), "FilterNumeric", GetNumberValidatorScript());

            this.Attributes.Add("onkeypress", "FilterNumeric()");

            /*rvl.ControlToValidate = this.txtNumber.ID;
            rvl.ValidationExpression = @"(^[-]?[1-9]\d+$)|(^[-]?[1-9]$)|(^0$)|(^[-]?[1-9]\d+\" + _strSeperator + @"\d$)|(^[-]?[0-9]\" + _strSeperator + @"\d$)";
            rvl.Font.Bold = true;
            rvl.Font.Name = "Arial";
            rvl.ErrorMessage = "Número inválido!";
            rvl.ToolTip = "NNNNN.N";
            //RegularExpressionValidator1.Display = ValidatorDisplay.None ;
            rvl.EnableViewState = false;
            rvl.Visible = true;*/
            base.OnInit(e);
        }
    }
}
