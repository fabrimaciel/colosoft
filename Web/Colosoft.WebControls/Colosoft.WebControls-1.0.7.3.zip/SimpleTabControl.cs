﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

namespace Colosoft.WebControls
{
    public class TabHeaderStyle
    {
        #region Variáveis Locais

        //private Unit _height;

        #endregion
    }

    public class SimpleTabControl : WebControl
    {
        #region Variáveis Locais

        
        #endregion
    }
}
