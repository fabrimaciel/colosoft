﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    public enum AjaxCallBackMode
    {
        None,
        RequestData,
        EditRow,
        AddRow,
        DeleteRow,
        Search
    }

    public enum EditType
    {
        TextBox,
        CheckBox,
        DropDown,
        TextArea,
        Password
    }

    public enum SearchDataType
    {
        NotSet,
        String,
        Date,
        Numerical,
        Other
    }

    public enum SearchOperation
    {
        IsEqualTo,
        IsNotEqualTo,
        IsLessThan,
        IsLessOrEqualTo,
        IsGreaterThan,
        IsGreaterOrEqualTo,
        IsIn,
        IsNotIn,
        BeginsWith,
        DoesNotBeginWith,
        EndsWith,
        DoesNotEndWith,
        Contains,
        DoesNotContain
    }

    public enum SearchType
    {
        TextBox,
        DropDown
    }

    public enum SortAction
    {
        ClickOnHeader,
        ClickOnSortIcons
    }

    public enum SortDirection
    {
        Asc,
        Desc
    }

    public enum SortIconsPosition
    {
        Vertical,
        Horizontal
    }

    public enum ToolBarPosition
    {
        Top,
        Bottom,
        TopAndBottom,
        Hidden
    }

    public enum ToolBarAlign
    {
        Left,
        Center,
        Right
    }

    public enum HierarchyMode
    {
        None,
        Parent,
        Child,
        ParentAndChild
    }

    /// <summary>
    /// Possíveis teclas que podem ser usadas para a multiseleção.
    /// </summary>
    public enum MultiSelectKey
    {
        None,
        Shift,
        Ctrl,
        Alt
    }

    /// <summary>
    /// Possíveis modos de multiseleção.
    /// </summary>
    public enum MultiSelectMode
    {
        SelectOnCheckBoxClickOnly,
        SelectOnRowClick
    }

    /// <summary>
    /// Possíveis modos de renderizar o GridView.
    /// </summary>
    public enum RenderingMode
    {
        Default,
        /// <summary>
        /// Esse modo otimiza ao velocidade do Grid, mas reduz algumas funcionalidades.
        /// </summary>
        Optimized
    }
}
