﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    internal class JsonRow
    {
        #region Publcs Variables

        public string id;

        #endregion

        #region Properties

        public object[] cell { get; set; }

        #endregion
    }
}
