﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Representa a resposta JSON para os dados do GridView.
    /// </summary>
    internal class JsonResponse
    {
        #region Properties

        public int page { get; set; }
        public int records { get; set; }
        public JsonRow[] rows { get; set; }
        public int total { get; set; }
        public Hashtable userdata { get; set; }

        #endregion
    }
}
