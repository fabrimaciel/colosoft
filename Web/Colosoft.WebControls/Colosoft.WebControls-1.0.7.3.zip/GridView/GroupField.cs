﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Armazena os dados de um campos do grupo.
    /// </summary>
    [System.Web.AspNetHostingPermission(System.Security.Permissions.SecurityAction.LinkDemand, Level=System.Web.AspNetHostingPermissionLevel.Minimal), 
     System.Web.AspNetHostingPermission(System.Security.Permissions.SecurityAction.InheritanceDemand, Level=System.Web.AspNetHostingPermissionLevel.Minimal)]
    public class GroupField : System.Web.UI.IStateManager
    {
        #region Local Variables

        private bool _isTracking;
        private System.Web.UI.StateBag _viewState = new System.Web.UI.StateBag();

        #endregion

        #region Properties

        /// <summary>
        /// Nome do campo de dados.
        /// </summary>
        public string DataField { get; set; }

        /// <summary>
        /// Direção da ordenação do grupo.
        /// </summary>
        public SortDirection GroupSortDirection { get; set; }

        /// <summary>
        /// Texto do cabeçalho.
        /// </summary>
        public string HeaderText { get; set; }

        /// <summary>
        /// Identifica se é para exibir a coluna do grupo.
        /// </summary>
        public bool ShowGroupColumn { get; set; }

        /// <summary>
        /// Identifica se é para exibir o resumo do grupo.
        /// </summary>
        public bool ShowGroupSummary { get; set; }

        /// <summary>
        /// Identifica se suporta TrackingViewState.
        /// </summary>
        bool System.Web.UI.IStateManager.IsTrackingViewState
        {
            get
            {
                return this._isTracking;
            }
        }

        /// <summary>
        /// Estado do controle.
        /// </summary>
        private System.Web.UI.StateBag ViewState
        {
            get
            {
                return this._viewState;
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        public GroupField()
        {
            this.DataField = "";
            this.HeaderText = "<b>{0}</b>";
            this.ShowGroupColumn = true;
            this.GroupSortDirection = SortDirection.Asc;
            this.ShowGroupSummary = false;
        }

        #endregion

        #region IStateManager Members

        void System.Web.UI.IStateManager.LoadViewState(object state)
        {
            if (state != null)
                ((System.Web.UI.IStateManager) this.ViewState).LoadViewState(state);
        }

        object System.Web.UI.IStateManager.SaveViewState()
        {
            return ((System.Web.UI.IStateManager) this.ViewState).SaveViewState();
        }

        void System.Web.UI.IStateManager.TrackViewState()
        {
            this._isTracking = true;
            ((System.Web.UI.IStateManager) this.ViewState).TrackViewState();
        }

        #endregion
    } 

}
