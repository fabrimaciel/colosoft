﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Classe que formata os dados para o Dialog de exclusão.
    /// </summary>
    internal class JsonDelDialog
    {
        #region Local Variables

        private GridView _grid;
        private Hashtable _jsonValues = new Hashtable();

        #endregion

        public JsonDelDialog(GridView grid)
        {
            _grid = grid;
        }

        public void Process()
        {
            DeleteDialogSettings deleteDialogSettings = _grid.DeleteDialogSettings;
            if (deleteDialogSettings.TopOffset != 0)
            {
                _jsonValues["top"] = deleteDialogSettings.TopOffset;
            }
            if (deleteDialogSettings.LeftOffset != 0)
            {
                _jsonValues["left"] = deleteDialogSettings.LeftOffset;
            }
            if (deleteDialogSettings.Width != 300)
            {
                _jsonValues["width"] = deleteDialogSettings.Width;
            }
            if (deleteDialogSettings.Height != 300)
            {
                _jsonValues["height"] = deleteDialogSettings.Height;
            }
            if (deleteDialogSettings.Modal)
            {
                _jsonValues["modal"] = true;
            }
            if (!deleteDialogSettings.Draggable)
            {
                _jsonValues["drag"] = false;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.SubmitText))
            {
                _jsonValues["bSubmit"] = deleteDialogSettings.SubmitText;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.CancelText))
            {
                _jsonValues["bCancel"] = deleteDialogSettings.CancelText;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.LoadingMessageText))
            {
                _jsonValues["processData"] = deleteDialogSettings.LoadingMessageText;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.Caption))
            {
                _jsonValues["caption"] = deleteDialogSettings.Caption;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.DeleteMessage))
            {
                _jsonValues["msg"] = deleteDialogSettings.DeleteMessage;
            }
            if (!deleteDialogSettings.ReloadAfterSubmit)
            {
                _jsonValues["reloadAfterSubmit"] = false;
            }
            if (!deleteDialogSettings.Resizable)
            {
                _jsonValues["resize"] = false;
            }
            if (!string.IsNullOrEmpty(deleteDialogSettings.FunctionErrorTextFormat))
            {
                _jsonValues["errorTextFormat"] = deleteDialogSettings.FunctionErrorTextFormat;
            }
        }

        /// <summary>
        /// Remove as aspas dos método javascript.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string RemoveQuotesForJavaScriptMethods(string input)
        {
            return input.Replace("\"errorTextFormat\":\"" + _grid.DeleteDialogSettings.FunctionErrorTextFormat +
                "\"", "\"errorTextFormat\":" + _grid.DeleteDialogSettings.FunctionErrorTextFormat);
        }

        public Hashtable JsonValues
        {
            get
            {
                return _jsonValues;
            }
            set
            {
                _jsonValues = value;
            }
        }
    }
}
