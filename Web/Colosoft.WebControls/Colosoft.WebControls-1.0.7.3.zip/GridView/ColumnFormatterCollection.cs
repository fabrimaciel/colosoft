﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class ColumnFormatterCollection : BaseItemCollection<Column, ColumnFormatter>
    {
        private static readonly Type[] _knownTypes = new Type[] { typeof(IntegerFormatter), typeof(LinkFormatter), typeof(EmailFormatter), typeof(CheckBoxFormatter), typeof(CurrencyFormatter), typeof(NumberFormatter), typeof(CustomFormatter) };
        
        protected override object CreateKnownType(int index)
        {
            switch (index)
            {
                case 0:
                    return new IntegerFormatter();

                case 1:
                    return new LinkFormatter();

                case 2:
                    return new EmailFormatter();

                case 3:
                    return new CheckBoxFormatter();

                case 4:
                    return new CurrencyFormatter();

                case 5:
                    return new NumberFormatter();

                case 6:
                    return new CustomFormatter();
            }
            throw new ArgumentOutOfRangeException("index");
        }

        protected override Type[] GetKnownTypes()
        {
            return _knownTypes;
        }
    }

 

}
