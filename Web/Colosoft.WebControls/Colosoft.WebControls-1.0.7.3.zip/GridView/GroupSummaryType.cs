﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Possíveis tipos de resumo para grupo.
    /// </summary>
    public enum GroupSummaryType
    {
        None,
        Min,
        Max,
        Sum,
        Avg,
        Count
    }
}
