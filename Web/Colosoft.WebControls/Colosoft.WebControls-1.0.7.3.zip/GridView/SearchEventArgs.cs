﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    public class SearchEventArgs : CancelEventArgs
    {
        // Fields
        private string _searchColumn;
        private SearchOperation _searchOperation;
        private string _searchString;

        // Methods
        public SearchEventArgs()
        {
        }

        public SearchEventArgs(string searchColumn, string searchString, SearchOperation searchOperation)
            : this()
        {
            this._searchColumn = searchColumn;
            this._searchString = searchString;
            this._searchOperation = searchOperation;
        }

        // Properties
        public string SearchColumn
        {
            get
            {
                return this._searchColumn;
            }
            set
            {
                this._searchColumn = value;
            }
        }

        public SearchOperation SearchOperation
        {
            get
            {
                return this._searchOperation;
            }
            set
            {
                this._searchOperation = value;
            }
        }

        public string SearchString
        {
            get
            {
                return this._searchString;
            }
            set
            {
                this._searchString = value;
            }
        }
    }

}
