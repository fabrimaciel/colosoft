﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Representa o argumento informado quando ocorre algum evento 
    /// relacionado ao link de dados.
    /// </summary>
    public class DataLinkEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Link de dados em questão.
        /// </summary>
        public object DataLink { get; set; }

        #endregion
    }
}
