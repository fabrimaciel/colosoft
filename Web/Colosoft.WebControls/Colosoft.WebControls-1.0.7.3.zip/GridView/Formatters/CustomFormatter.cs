﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.Web.UI;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class CustomFormatter : ColumnFormatter, IStateManager
    {
        #region Local Variables

        private bool _isTracking;
        private StateBag _viewState = new StateBag();

        #endregion

        #region Métods

        void IStateManager.LoadViewState(object state)
        {
            if (state != null)
            {
                ((IStateManager)this.ViewState).LoadViewState(state);
            }
        }

        object IStateManager.SaveViewState()
        {
            return ((IStateManager)this.ViewState).SaveViewState();
        }

        void IStateManager.TrackViewState()
        {
            this._isTracking = true;
            ((IStateManager)this.ViewState).TrackViewState();
        }

        #endregion

        #region Properties

        [DefaultValue(""), NotifyParentProperty(true), Category("Behavior"), 
         Description("The javascript function that will format the value. The first parameter is the cell value.")]
        public string FormatFunction
        {
            get
            {
                if (this.ViewState["FormatFunction"] != null)
                {
                    return (string)this.ViewState["FormatFunction"];
                }
                return "";
            }
            set
            {
                this.ViewState["FormatFunction"] = value;
            }
        }

        bool IStateManager.IsTrackingViewState
        {
            get
            {
                return this._isTracking;
            }
        }

        [NotifyParentProperty(true), Category("Behavior"), Description("The javascript function that will unformat the value upon editing. The first parameter is the formatted value."), DefaultValue("")]
        public string UnFormatFunction
        {
            get
            {
                if (this.ViewState["UnFormatFunction"] != null)
                {
                    return (string)this.ViewState["UnFormatFunction"];
                }
                return "";
            }
            set
            {
                this.ViewState["UnFormatFunction"] = value;
            }
        }

        private StateBag ViewState
        {
            get
            {
                return this._viewState;
            }
        }

        #endregion
    }
}
