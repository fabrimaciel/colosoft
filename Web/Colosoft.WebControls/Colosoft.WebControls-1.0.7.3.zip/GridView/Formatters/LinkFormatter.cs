﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level=AspNetHostingPermissionLevel.Minimal), AspNetHostingPermission(SecurityAction.LinkDemand, Level=AspNetHostingPermissionLevel.Minimal)]
    public class LinkFormatter : ColumnFormatter
    {
        // Properties
        [DefaultValue(""), Description("If specified, set target for the link (e.g. '_blank', name of frame/iframe, etc")]
        public string Target { get; set; }
    }


}
