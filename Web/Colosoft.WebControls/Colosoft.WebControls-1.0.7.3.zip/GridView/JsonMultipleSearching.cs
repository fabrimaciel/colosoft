﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    internal class MultipleSearchRule
    {
        #region Properties

        public string data { get; set; }
        public string field { get; set; }
        public string op { get; set; }

        #endregion
    }

    internal class JsonMultipleSearch
    {
        #region Properties

        public string groupOp { get; set; }
        public List<MultipleSearchRule> rules { get; set; }

        #endregion
    }
}
