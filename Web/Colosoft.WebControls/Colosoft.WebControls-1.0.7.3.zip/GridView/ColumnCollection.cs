﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Representa uma coleção de colunas.
    /// </summary>
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class ColumnCollection : BaseItemCollection<GridView, Column>
    {
        #region Protecteds Methods

        protected override object CreateKnownType(int index)
        {
            return new Column();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Recupera a coluna com base no campo de dados.
        /// </summary>
        /// <param name="dataField"></param>
        /// <returns></returns>
        public Column FromDataField(string dataField)
        {
            for (int i = 0; i < base.Count; i++)
            {
                var column = base[i];
                if (column.QualifiedName == dataField)
                    return column;
            }
            return null;
        }

        #endregion
    }
}
