﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    public class RowDeleteEventArgs : CancelEventArgs
    {
        private string _rowKey;

        public string RowKey
        {
            get
            {
                return this._rowKey;
            }
            set
            {
                this._rowKey = value;
            }
        }
    }

}
