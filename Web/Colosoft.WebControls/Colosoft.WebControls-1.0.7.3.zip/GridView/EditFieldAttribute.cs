﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web;
using System.Security.Permissions;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class EditFieldAttribute : IStateManager
    {
        #region Local Variables

        private bool _isTracking;
        private StateBag _viewState = new StateBag();

        #endregion

        #region Members Of IStateManager

        void IStateManager.LoadViewState(object state)
        {
            if (state != null)
            {
                ((IStateManager)ViewState).LoadViewState(state);
            }
        }

        object IStateManager.SaveViewState()
        {
            return ((IStateManager)ViewState).SaveViewState();
        }

        void IStateManager.TrackViewState()
        {
            this._isTracking = true;
            ((IStateManager)ViewState).TrackViewState();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Nome do atributo do campo.
        /// </summary>
        [DefaultValue(""), NotifyParentProperty(true), 
         Category("Behavior"), Description("The name of the HTML attribute")]
        public string Name
        {
            get
            {
                if (ViewState["Name"] != null)
                    return (string)ViewState["Name"];
                
                return "";
            }
            set
            {
                ViewState["Name"] = value;
            }
        }

        bool IStateManager.IsTrackingViewState
        {
            get
            {
                return _isTracking;
            }
        }

        /// <summary>
        /// Valor do atributo.
        /// </summary>
        [DefaultValue(""), Description(""), NotifyParentProperty(true), 
         Category("Behavior")]
        public string Value
        {
            get
            {
                if (ViewState["Value"] != null)
                    return (string)ViewState["Value"];
                
                return "";
            }
            set
            {
                ViewState["Value"] = value;
            }
        }

        private StateBag ViewState
        {
            get
            {
                return _viewState;
            }
        }

        #endregion
    }
}
