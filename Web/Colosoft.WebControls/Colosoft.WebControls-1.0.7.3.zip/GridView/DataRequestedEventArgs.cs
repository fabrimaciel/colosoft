﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Colosoft.WebControls.GridView
{
    public class DataRequestedEventArgs : EventArgs
    {
        public DataTable DataTable { get; set; }

        public DataRequestedEventArgs(DataTable dt)
        {
            this.DataTable = dt;
        }
    }

}
