﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Assinatura da classe que representa um formatador de valores das colunas.
    /// </summary>
    public interface IColumnValuesFormatter
    {
        #region Methods

        /// <summary>
        /// Método usado para formatar o valor.
        /// </summary>
        /// <param name="instance">Instancia do objeto onde está contido a propriedade
        /// do valor que está sendo formatado.</param>
        /// <param name="dataField">Nome do campo de dados que está sendo formatado.</param>
        /// <param name="value">Valor que será formatado.</param>
        /// <returns>Valor formatado.</returns>
        string Format(object instance, string dataField, object value);

        /// <summary>
        /// Método usado para remover a formatação do valor.
        /// </summary>
        /// <param name="instanceType">Tipo da instancia do objeto onde está contido a propriedade
        /// do valor que está sendo formatado.</param>
        /// <param name="dataField">Nome do campo de dados que está sendo formatado.</param>
        /// <param name="value">Valor formatado.</param>
        /// <returns></returns>
        object Unformat(Type instanceType, string dataField, string value);

        #endregion
    }
}
