﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    public class DataRequestEventArgs : EventArgs
    {
        private int _newPageIndex;
        private int _totalRows;

        public DataRequestEventArgs(string sortExpression, string sortDirection, int newPageIndex, string searchExpression, string parentRowKey)
        {
            this.SortExpression = sortExpression;
            this._newPageIndex = newPageIndex;
            this.SearchExpression = searchExpression;
            this.ParentRowKey = parentRowKey;
            if (sortDirection == null)
            {
                sortDirection = string.Empty;
            }
            this.SortDirection = (sortDirection.ToLower() == "asc") ? SortDirection.Asc : SortDirection.Desc;
        }

        public int NewPageIndex
        {
            get
            {
                return this._newPageIndex;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                this._newPageIndex = value;
            }
        }

        public string ParentRowKey { get; set; }
        public string SearchExpression { get; set; }

        public SortDirection SortDirection { get; set; }

        public string SortExpression { get; set; }

        public int TotalRows
        {
            get
            {
                return this._totalRows;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                this._totalRows = value;
            }
        }
    }

}
