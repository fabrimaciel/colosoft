﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.ComponentModel;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls.GridView
{
    [TypeConverter(typeof(ExpandableObjectConverter)), 
     AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public sealed class HierarchySettings : IStateManager
    {
        // Fields
        private bool _isTracking;
        private StateBag _viewState = new StateBag();

        // Methods
        void IStateManager.LoadViewState(object state)
        {
            if (state != null)
            {
                ((IStateManager)this.ViewState).LoadViewState(state);
            }
        }

        object IStateManager.SaveViewState()
        {
            return ((IStateManager)this.ViewState).SaveViewState();
        }

        void IStateManager.TrackViewState()
        {
            this._isTracking = true;
            ((IStateManager)this.ViewState).TrackViewState();
        }

        public override string ToString()
        {
            return string.Empty;
        }

        // Properties
        [NotifyParentProperty(true), Description("Determines the position of the grid in the Hierarchy. Possible values are Parent, ParentAndChild and Child."), DefaultValue(0), Category("Appearance")]
        public HierarchyMode HierarchyMode
        {
            get
            {
                object obj2 = this.ViewState["HierarchyMode"];
                if (obj2 == null)
                {
                    return HierarchyMode.None;
                }
                return (HierarchyMode)obj2;
            }
            set
            {
                this.ViewState["HierarchyMode"] = value;
            }
        }

        bool IStateManager.IsTrackingViewState
        {
            get
            {
                return this._isTracking;
            }
        }

        private StateBag ViewState
        {
            get
            {
                return this._viewState;
            }
        }
    }
}
