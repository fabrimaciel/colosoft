﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.GridView
{
    /// <summary>
    /// Representa uma coleção de campos de grupo.
    /// </summary>
    [System.Web.AspNetHostingPermission(System.Security.Permissions.SecurityAction.LinkDemand, Level = System.Web.AspNetHostingPermissionLevel.Minimal), 
     System.Web.AspNetHostingPermission(System.Security.Permissions.SecurityAction.InheritanceDemand, Level = System.Web.AspNetHostingPermissionLevel.Minimal)]
    public class GroupFieldCollection : BaseItemCollection<GridView, GroupField>
    {
        #region Public Methods

        /// <summary>
        /// Cria um tipo conhecido.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        protected override object CreateKnownType(int index)
        {
            return new GroupField();
        }

        #endregion
    }
}
