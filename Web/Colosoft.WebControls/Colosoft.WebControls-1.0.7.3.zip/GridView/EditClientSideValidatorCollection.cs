﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class EditClientSideValidatorCollection : BaseItemCollection<Column, EditClientSideValidator>
    {
        #region Local Variables

        private static readonly Type[] _knownTypes = new Type[] { typeof(DateValidator), typeof(CustomValidator), typeof(IntegerValidator), typeof(MaxValueValidator), typeof(MinValueValidator), typeof(NumberValidator), typeof(RequiredValidator), typeof(TimeValidator), typeof(UrlValidator), typeof(CustomValidator) };

        #endregion

        #region Protecteds Methods

        protected override object CreateKnownType(int index)
        {
            switch (index)
            {
                case 0:
                    return new DateValidator();

                case 1:
                    return new CustomValidator();

                case 2:
                    return new IntegerValidator();

                case 3:
                    return new MaxValueValidator();

                case 4:
                    return new MinValueValidator();

                case 5:
                    return new NumberValidator();

                case 6:
                    return new RequiredValidator();

                case 7:
                    return new TimeValidator();

                case 8:
                    return new UrlValidator();

                case 9:
                    return new CustomValidator();
            }
            throw new ArgumentOutOfRangeException("index");
        }

        /// <summary>
        /// Recupera os tipos conhecidos.
        /// </summary>
        /// <returns></returns>
        protected override Type[] GetKnownTypes()
        {
            return _knownTypes;
        }

        #endregion
    }
}
