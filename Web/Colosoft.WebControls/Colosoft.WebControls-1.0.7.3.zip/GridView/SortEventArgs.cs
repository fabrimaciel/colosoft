﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    public class SortEventArgs : CancelEventArgs
    {
        // Fields
        private SortDirection _sortDirection;
        private string _sortExpression;

        // Methods
        public SortEventArgs(string sortExpression, string sortDirection)
        {
            this._sortExpression = sortExpression;
            if (sortDirection != null)
            {
                this._sortDirection = (sortDirection.ToLower() == "asc") ? SortDirection.Asc : SortDirection.Desc;
            }
            else
            {
                this._sortDirection = SortDirection.Asc;
            }
        }

        // Properties
        public SortDirection SortDirection
        {
            get
            {
                return this._sortDirection;
            }
            set
            {
                this._sortDirection = value;
            }
        }

        public string SortExpression
        {
            get
            {
                return this._sortExpression;
            }
            set
            {
                this._sortExpression = value;
            }
        }
    }

}
