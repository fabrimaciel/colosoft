﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Collections.Specialized;

namespace Colosoft.WebControls.GridView
{
    public class RowAddEventArgs : CancelEventArgs
    {
        private string _parentRowKey;
        private NameValueCollection _rowData;

        public string ParentRowKey
        {
            get
            {
                return this._parentRowKey;
            }
            set
            {
                this._parentRowKey = value;
            }
        }

        public NameValueCollection RowData
        {
            get
            {
                return this._rowData;
            }
            set
            {
                this._rowData = value;
            }
        }
    }

}
