﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace Colosoft.WebControls.GridView
{
    public class PageEventArgs : CancelEventArgs
    {
        // Fields
        private int _newPageIndex;
        private int _totalRows;

        // Methods
        public PageEventArgs(int newPageIndex)
        {
            this._newPageIndex = newPageIndex;
        }

        // Properties
        public int NewPageIndex
        {
            get
            {
                return this._newPageIndex;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                this._newPageIndex = value;
            }
        }

        public int TotalRows
        {
            get
            {
                return this._totalRows;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("value");
                }
                this._totalRows = value;
            }
        }
    }

}
