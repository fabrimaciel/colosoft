﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls.GridView
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class EditFieldAttributeCollection : BaseItemCollection<Column, EditFieldAttribute>
    {
        private static readonly Type[] _knownTypes = new Type[] { typeof(EditFieldAttribute) };

        protected override object CreateKnownType(int index)
        {
            if (index != 0)
            {
                throw new ArgumentOutOfRangeException("index");
            }
            return new EditFieldAttribute();
        }

        protected override Type[] GetKnownTypes()
        {
            return _knownTypes;
        }
    }

 

}
