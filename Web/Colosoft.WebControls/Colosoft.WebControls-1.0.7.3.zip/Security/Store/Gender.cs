﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.Security.Store {

    /// <summary>
    /// 
    /// </summary>
    public enum Gender {
        /// <summary>
        /// 
        /// </summary>
        Unspecified = 0,
        /// <summary>
        /// 
        /// </summary>
        Male        = 1,
        /// <summary>
        /// 
        /// </summary>
        Female      = 2
    }
}
