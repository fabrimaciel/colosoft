using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.CompilerServices;
using System.Security.Permissions;

namespace Colosoft.WebControls.Security.Store {

    /// <summary>
    /// 
    /// </summary>
    public partial class XmlUserStore : Persistable<List<XmlUser>> {

        #region Properties

        /// <summary>
        /// Gets the users.
        /// </summary>
        /// <value>The users.</value>
        public virtual List<XmlUser> Users {
            get { return this.Value; }
        }
        #endregion

        #region Construct

        /// <summary>
        /// Initializes a new instance of the <see cref="UserStore"/> class.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        public XmlUserStore(string fileName)
            : base(fileName) {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="XmlUserStore"/> class.
        /// </summary>
        protected XmlUserStore()
            : base(null) {
        }
        #endregion

        #region Methods

        /// <summary>
        /// Gets the user by email.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        public virtual XmlUser GetUserByEmail(string email) {

            lock (SyncRoot) {
                return (Users != null)
                    ? Users.Find(delegate(XmlUser user) { return string.Equals(email, user.Email); })
                    : null;
            }
        }

        /// <summary>
        /// Gets the user by key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public virtual XmlUser GetUserByKey(Guid key) {

            lock (SyncRoot) {
                return (Users != null)
                    ? Users.Find(delegate(XmlUser user) { return (user.UserKey.CompareTo(key) == 0); })
                    : null;
            }
        }

        /// <summary>
        /// Gets the name of the user by.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public virtual XmlUser GetUserByName(string name) {

            lock (SyncRoot) {
                return (Users != null)
                    ? Users.Find(delegate(XmlUser user) { return string.Equals(name, user.UserName); })
                    : null;
            }
        }
        #endregion
    }
}
