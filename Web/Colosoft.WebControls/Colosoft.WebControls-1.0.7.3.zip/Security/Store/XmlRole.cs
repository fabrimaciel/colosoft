using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.Security.Store {

    /// <summary>
    /// 
    /// </summary>
    public class XmlRole {

        #region Fields

        public string Name = string.Empty;
        public List<string> Users = new List<string>(); 

        #endregion
    }
}
