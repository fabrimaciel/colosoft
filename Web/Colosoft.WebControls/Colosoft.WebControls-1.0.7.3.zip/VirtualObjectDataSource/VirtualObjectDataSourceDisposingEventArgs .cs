﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.ComponentModel;

namespace Colosoft.WebControls
{
    public delegate void VirtualObjectDataSourceDisposingEventHandler(object sender, VirtualObjectDataSourceDisposingEventArgs e);

    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceDisposingEventArgs : CancelEventArgs
    {
        public VirtualObjectDataSourceDisposingEventArgs(object objectInstance)
        {
            ObjectInstance = objectInstance;
        }

        public object ObjectInstance { get; private set; }
    }
}
