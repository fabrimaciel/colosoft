﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Web;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Assinatura do evento acionadp quando os itens estiverem sendo selecionados
    /// pelas chaves informadas.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void VirtualObjectDataSourceSeletingByKeysEventHandler(object sender, VirtualObjectDataSourceSeletingByKeysEventArgs e);

    /// <summary>
    /// Argumentos do evento acionado quando estiver sendo selecionados
    /// os dados pelas chaves.
    /// </summary>
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal),
     AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceSeletingByKeysEventArgs : VirtualObjectDataSourceMethodEventArgs
    {
        #region Local Variables

        private IDictionary _keys;

        #endregion

        #region Properties

        /// <summary>
        /// Chaves que serão usadas na seleção.
        /// </summary>
        public IDictionary Keys
        {
            get { return _keys; }
        }

        #endregion

        #region Constructords

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        /// <param name="inputParameters">Parametros de entrada.</param>
        /// <param name="keys">Chaves que serão utilizadas.</param>
        public VirtualObjectDataSourceSeletingByKeysEventArgs(
            IOrderedDictionary inputParameters,
            IDictionary keys)
            : base(inputParameters)
        {
            _keys = keys;
        }

        #endregion
    }
}
