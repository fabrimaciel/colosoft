﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Web;
using System.Security.Permissions;
using System.Collections.Specialized;

namespace Colosoft.WebControls
{
    public delegate void VirtualObjectDataSourceMethodEventHandler(object sender, VirtualObjectDataSourceMethodEventArgs e);

    /// <summary>
    /// Classe base dos argumento dos método do DataSource.
    /// </summary>
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceMethodEventArgs : CancelEventArgs
    {
        #region Local Variables

        private IOrderedDictionary _inputParameters;

        #endregion

        #region Properties

        /// <summary>
        /// Parametros de entrada.
        /// </summary>
        public IOrderedDictionary InputParameters
        {
            get
            {
                return _inputParameters;
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        /// <param name="inputParameters"></param>
        public VirtualObjectDataSourceMethodEventArgs(IOrderedDictionary inputParameters)
        {
            _inputParameters = inputParameters;
        }

        #endregion
    } 

}
