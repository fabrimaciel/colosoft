﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.Web.UI;
using System.Collections.Specialized;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Assinatura do evento acionado quando os dados estiverem sendo selecionados pelo DataSource.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void VirtualObjectDataSourceSelectingEventHandler(object sender, VirtualObjectDataSourceSelectingEventArgs e);

    /// <summary>
    /// Argumentos do evento acionado quando os dados estiverem sendo selecionaos pelo DataSource.
    /// </summary>
    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceSelectingEventArgs : VirtualObjectDataSourceMethodEventArgs
    {
        #region Properties
        
        /// <summary>
        /// Argumentos da seleção.
        /// </summary>
        public DataSourceSelectArguments Arguments { get; private set; }

        /// <summary>
        /// Identifica se está executando do seleção da quantidade de itens.
        /// </summary>
        public bool ExecutingSelectCount { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        /// <param name="inputParameters"></param>
        /// <param name="arguments"></param>
        /// <param name="executingSelectCount"></param>
        public VirtualObjectDataSourceSelectingEventArgs(IOrderedDictionary inputParameters, DataSourceSelectArguments arguments, bool executingSelectCount)
            : base(inputParameters)
        {
            Arguments = arguments;
            ExecutingSelectCount = executingSelectCount;
        }

        #endregion
    }
}
