﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Colosoft.WebControls
{
    class SqlDataSourceCache : DataSourceCache
    {
        #region Properties

        /// <summary>
        /// Chave do SqlCacheDependency.
        /// </summary>
        public string SqlCacheDependency
        {
            get
            {
                object obj2 = base.ViewState["SqlCacheDependency"];
                if (obj2 != null)
                {
                    return (string)obj2;
                }
                return string.Empty;
            }
            set
            {
                base.ViewState["SqlCacheDependency"] = value;
            }
        }

        #endregion
    }
}
