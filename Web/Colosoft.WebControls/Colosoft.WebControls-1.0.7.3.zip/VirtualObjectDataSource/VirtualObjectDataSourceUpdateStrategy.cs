﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Possíveis estratégias de atualização.
    /// </summary>
    public enum VirtualObjectDataSourceUpdateStrategy
    {
        /// <summary>
        /// Estratégia normal para atualização. É criada uma 
        /// nova instância, os dados serão preenchidos e logo após 
        /// são salvos.
        /// </summary>
        Normal,
        /// <summary>
        /// Estratégia onde para atualizar o método de consulta é executado
        /// para recuperar os dados  e logo
        /// após são atualizados.
        /// </summary>
        GetAndUpdate
    }
}
