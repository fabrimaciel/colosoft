﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls
{
    public delegate void VirtualObjectDataSourceObjectEventHandler(object sender, VirtualObjectDataSourceEventArgs e);

    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceEventArgs : EventArgs
    {
        public VirtualObjectDataSourceEventArgs(object objectInstance)
        {
            ObjectInstance = objectInstance;
        }

        public object ObjectInstance { get; set; }
    }

 

}
