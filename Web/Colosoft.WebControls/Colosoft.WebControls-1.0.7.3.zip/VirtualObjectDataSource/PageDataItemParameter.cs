﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Representa o parametro do item de dados associado a página.
    /// </summary>
    public class PageDataItemParameter : Parameter
    {
        #region Properties

        /// <summary>
        /// Nome da propriedade do item de dados.
        /// </summary>
        public string PropertyName { get; set; }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Recupera o valor.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="control"></param>
        /// <returns></returns>
        protected override object Evaluate(System.Web.HttpContext context, System.Web.UI.Control control)
        {
            return System.Web.UI.DataBinder.Eval(control.Page.GetDataItem(), PropertyName);
        }

        #endregion
    }
}
