﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Representa o parametro da propriedade de um controle.
    /// </summary>
    public class PropertyParameter : Parameter
    {
        /// <summary>
        /// Nome da propriedade.
        /// </summary>
        public string PropertyName { get; set; }

        #region Protected Methods

        protected override object Evaluate(HttpContext context, Control control)
        {
            Control propertyControl = GetContainingControl(control);
            
            if (propertyControl != null)
            {
                return DataBinder.Eval(propertyControl, PropertyName);
            }
            else
            {
                throw new ApplicationException(string.Format("Unable to find property: {0}", PropertyName));
            }
        }

        #endregion

        #region Private Methods

        private Control GetContainingControl(Control control)
        {
            //Check if the property exists in the control
            var propertyInfo = control.GetType().GetProperty(PropertyName);

            if (propertyInfo != null)
            {
                //Check that the property type matching the type set for this parameter
                if (System.Type.GetTypeCode(propertyInfo.PropertyType).Equals(Type))
                {
                    return control;
                }
            }

            //Check if the control has a parent, and if so call this method again passing the parent as the control
            if (control.Parent == null)
            {
                return null;
            }
            else
            {
                return GetContainingControl(control.Parent);
            }
        }

        #endregion
    }
}
