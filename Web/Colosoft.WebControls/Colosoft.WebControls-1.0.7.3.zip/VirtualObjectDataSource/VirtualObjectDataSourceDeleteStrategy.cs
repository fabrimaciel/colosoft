﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Possíveis estratégias de exclusão.
    /// </summary>
    public enum VirtualObjectDataSourceDeleteStrategy
    {
        /// <summary>
        /// Exclusão normal.
        /// </summary>
        Normal,
        /// <summary>
        /// Recupera os dados do item e depois acionao o método de exclusão.
        /// </summary>
        GetAndDelete
    }
}
