﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Colosoft.WebControls
{
    public delegate void VirtualObjectDataSourceFilteringEventHandler(object sender, VirtualObjectDataSourceFilteringEventArgs e);

    [AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal), AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class VirtualObjectDataSourceFilteringEventArgs : CancelEventArgs
    {
        public VirtualObjectDataSourceFilteringEventArgs(IOrderedDictionary parameterValues)
        {
            ParameterValues = parameterValues;
        }

        public IOrderedDictionary ParameterValues { get; private set; }
    }

 

}
