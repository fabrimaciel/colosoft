﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;

namespace Colosoft.WebControls.Route
{
    public class RouteHandler : IHttpHandler, IRequiresSessionState
    {
        #region Membros de IHttpHandler

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            RouteModule.SendAccessIsDaniedResponse(context.Response);
        }

        #endregion
    }
}
