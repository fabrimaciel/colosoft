﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Security.Principal;

namespace Colosoft.WebControls.Route.Security
{
    public class AuthorizationRuleCollection : Collection<AuthorizationRule>
    {
        /// <summary>
        /// Registra as informações da regra no requisição.
        /// </summary>
        /// <param name="rule"></param>
        private void RegisterAuthRuleInfo(AuthorizationRule rule)
        {
            System.Web.HttpContext.Current.Items[AuthorizationRule.AUTH_RULE_CONTEXT_ID] = rule;
        }

        /// <summary>
        /// Verifica se o usuário é permitido dentro das regras aplicadas.
        /// </summary>
        /// <param name="principal"></param>
        /// <param name="requestedPath"></param>
        /// <param name="verb"></param>
        /// <returns></returns>
        internal bool IsUserAllowed(IPrincipal principal, string requestedPath, string verb)
        {
            bool result = this.Count == 0;

            if (!result)
            {
                
                foreach (AuthorizationRule rule in this)
                {
                    if (rule.Type == AuthorizationRuleType.Roles)
                    {
                        if (!rule.Everyone)
                        {
                            foreach (var se in rule.Data)
                            {
                                if (rule.Everyone ||
                                    (principal != null && (principal is GenericPrincipal && System.Web.Security.Roles.Provider != null ?
                                        System.Web.Security.Roles.IsUserInRole(se) : principal.IsInRole(se))))
                                {
                                    RegisterAuthRuleInfo(rule);
                                    result = rule.Action == AuthorizationRuleAction.Allow;
                                    //break; //one role is enough
                                }
                            }
                        }
                        else
                        {
                            RegisterAuthRuleInfo(rule);
                            result = rule.Action == AuthorizationRuleAction.Allow;
                        }
                    }
                    else if (rule.Type == AuthorizationRuleType.Users)
                    {
                        if ((rule.Anonymous && (principal == null || principal.Identity == null || !principal.Identity.IsAuthenticated)) 
                            || rule.Everyone)
                        {
                            RegisterAuthRuleInfo(rule);
                            result = rule.Action == AuthorizationRuleAction.Allow;
                        }
                        else if (principal != null && principal.Identity != null && principal.Identity.IsAuthenticated)
                        {
                            result = true;

                            if (!rule.Everyone)
                            {
                                foreach (var se in rule.Data)
                                {
                                    if (string.Equals(se, principal.Identity.Name, StringComparison.OrdinalIgnoreCase))
                                    {
                                        RegisterAuthRuleInfo(rule);
                                        result = rule.Action == AuthorizationRuleAction.Allow;
                                    }
                                }
                            }
                            else
                            {
                                RegisterAuthRuleInfo(rule);
                                result = rule.Action == AuthorizationRuleAction.Allow;
                            }
                        }
                    }
                    else if (rule.Type == AuthorizationRuleType.HttpVerbs)
                    {
                        foreach (var se in rule.Data)
                        {
                            if (string.Equals(se, verb, StringComparison.OrdinalIgnoreCase))
                            {
                                RegisterAuthRuleInfo(rule);
                                result = rule.Action == AuthorizationRuleAction.Allow;
                            }
                        }
                    }
                    /*if (!result)
                        break; //one role is enough;*/
                }
            }

            return result;
        }
    }
}
