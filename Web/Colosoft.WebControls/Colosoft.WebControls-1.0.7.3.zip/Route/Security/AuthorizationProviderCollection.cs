﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace Colosoft.WebControls.Route.Security
{
    public class AuthorizationProviderCollection : ProviderCollection
    {
        public override void Add(ProviderBase provider)
        {
            if (provider == null)
                throw new ArgumentNullException("provider");

            if (!(provider is AuthorizationProvider))
                throw new ArgumentException("InvalidProviderType");

            base.Add(provider);
        }

        public new AuthorizationProvider this[string name]
        {
            get
            {
                return (AuthorizationProvider)base[name];
            }
        }
    }
}
