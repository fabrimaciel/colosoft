﻿using System;
using System.Threading;

namespace Colosoft.WebControls.Route.Security
{
    public class CachingRulesEventArgs : EventArgs
    {
        public CachingRulesEventArgs()
        {
            this.ClearCache = true;
        }

        /// <summary>
        /// Identifica se o cache foi limpo
        /// </summary>
        public bool ClearCache { get; set; }
    }

    /// <summary>
    /// Classe estática responsável por gerenciar o cache e que é compartilhada por toda a aplicação.
    /// Além de manter a coleção das políticas da aplicação, também possui um objeto do tipo ReaderWriterLockSlim
    /// (namespace System.Threading) que gerencia o acesso concorrente ao cache. 
    /// Esse tipo de objeto garante múltiplas threads para leitura ou o acesso exclusivo para escrita.
    /// </summary>
    public static class CacheManager
    {
        private static AuthorizationRuleCollection _rules;
        private static object objLock = new object();
        
        /// <summary>
        /// Armazenar em cache todas as políticas de acesso da aplicação corrente.
        /// </summary>
        public static AuthorizationRuleCollection Rules
        {
            get
            {
                lock (objLock) return _rules;
            }
            set
            {
                lock (objLock) _rules = value;
            }
        }
    }
}
