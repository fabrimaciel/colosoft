﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Colosoft.WebControls.Route.Security
{
    public class InvalidCaracterException : Exception
    {
        public InvalidCaracterException() { }

        public InvalidCaracterException(string message)
            : base(message) { }

        public InvalidCaracterException(string message, Exception exception)
            : base(message, exception) { }

        protected InvalidCaracterException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}
