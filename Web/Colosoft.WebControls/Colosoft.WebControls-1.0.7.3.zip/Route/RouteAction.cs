﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.Route
{
    /// <summary>
    /// Dados da resposta de uma ação do rota.
    /// </summary>
    public class RouteActionResponse
    {
        #region Local Variables

        private bool _compiled = true;

        #endregion

        #region Properties

        /// <summary>
        /// Caminho para onde a rota será redirecionada.
        /// </summary>
        public string RedirectVirtualPath { get; private set; }

        /// <summary>
        /// Identifica se o redirecionamento é compilado ou não.
        /// </summary>
        public bool Compiled
        {
            get { return _compiled; }
            private set { _compiled = value; }
        }

        /// <summary>
        /// Novo manipulador que será usado para a rota.
        /// </summary>
        public System.Web.IHttpHandler RouteHandler { get; private set; }

        #endregion

        #region Constructors

        /// <summary>
        /// Construtor padrão.
        /// </summary>
        public RouteActionResponse()
        {

        }

        /// <summary>
        /// Resposta informanado o nome manipulador.
        /// </summary>
        /// <param name="routeHandler">Novo manipulador que será usado para a rota.</param>
        public RouteActionResponse(System.Web.IHttpHandler routeHandler)
        {
            RouteHandler = routeHandler;
        }

        /// <summary>
        /// Resposta com redirecionamento.
        /// </summary>
        /// <param name="redirectVirtualPath">Caminho para onde a rota será redirecionada.</param>
        /// <param name="compiled">Identifica se o redirecionamento é compilado ou não.</param>
        public RouteActionResponse(string redirectVirtualPath, bool compiled)
        {
            RedirectVirtualPath = redirectVirtualPath;
            _compiled = compiled;
        }

        #endregion
    }

    /// <summary>
    /// Dados da requição da ação da rota.
    /// </summary>
    public class RouteActionRequest
    {
        #region Properties

        /// <summary>
        /// Caminho de destino da rota.
        /// </summary>
        public string DestinationVirtualPath { get; internal set; }

        /// <summary>
        /// QueryString original da requisição.
        /// </summary>
        public System.Collections.Specialized.NameValueCollection OriginalQueryString { get; internal set; }

        /// <summary>
        /// Parametros do roteamento.
        /// </summary>
        public System.Collections.Specialized.NameValueCollection RouteParameters { get; internal set; }

        /// <summary>
        /// Contexto da requisição.
        /// </summary>
        public System.Web.HttpContext Context { get; internal set; }

        #endregion
    }

    /// <summary>
    /// Dados da requição da ação da rota.
    /// </summary>
    public class RouteActionBeginRequest
    {
        #region Properties

        /// <summary>
        /// Contexto da requisição.
        /// </summary>
        public System.Web.HttpContext Context { get; internal set; }

        #endregion
    }

    /// <summary>
    /// Dados da resposta da requisição.
    /// </summary>
    public class RouteActionBeginResponse
    {
        #region Properties

        /// <summary>
        /// Aplica as alterações.
        /// </summary>
        public bool ApplyChanges { get; set; }

        /// <summary>
        /// Identifica que a página exige segurança.
        /// </summary>
        public bool IsSecurePage { get; set; }

        /// <summary>
        /// Força a rota não atender páginas de segurança.
        /// </summary>
        public bool ForceNoSecurePage { get; set; }

        #endregion
    }

    /// <summary>
    /// Classe responsável processamento da ação relacionada com a rota.
    /// </summary>
    public abstract class RouteAction
    {
        #region Internal Methods       

        /// <summary>
        /// Método acionado quando a rota é inicialmente requisitada.
        /// </summary>
        /// <param name="route"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        internal RouteActionBeginResponse BeginRequest(RouteInfo route, RouteActionBeginRequest request)
        {
            return OnBeginRequest(route, request);
        }

        /// <summary>
        /// Método acionado para o pré-carregamento da rota.
        /// </summary>
        /// <param name="route"></param>
        /// <returns></returns>
        internal RouteActionResponse PreLoad(RouteInfo route, RouteActionRequest request)
        {
            return OnPreLoad(route, request);
        }

        /// <summary>
        /// Método acionado para o carregamento da rota.
        /// </summary>
        /// <param name="route"></param>
        internal void Load(RouteInfo route)
        {
            OnLoad(route);
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Método acionado quando a rota é inicialmente requisitada.
        /// </summary>
        /// <param name="route"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        protected virtual RouteActionBeginResponse OnBeginRequest(RouteInfo route, RouteActionBeginRequest request)
        {
            return new RouteActionBeginResponse();
        }

        /// <summary>
        /// Método acionado no pré-processamento da rota.
        /// </summary>
        /// <param name="route"></param>
        /// <param name="request">Dados que estão sendo requisitados.</param>
        /// <returns></returns>
        protected virtual RouteActionResponse OnPreLoad(RouteInfo route, RouteActionRequest request)
        {
            return new RouteActionResponse();
        }

        /// <summary>
        /// Método acionado quando a rota for carregada.
        /// </summary>
        /// <param name="route"></param>
        protected virtual void OnLoad(RouteInfo route)
        {

        }

        #endregion
    }
}
