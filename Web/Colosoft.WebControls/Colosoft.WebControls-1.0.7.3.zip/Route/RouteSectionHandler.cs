﻿using System;
using System.Collections.Generic;
using System.Text;
using Colosoft.Configuration.Handlers;
using System.Configuration;
using System.Xml;

namespace Colosoft.WebControls.Route
{
    public class RouteSectionHandler : BaseSectionHandler, IConfigurationSectionHandler
    {
        /// <summary>
        /// Construtor.
        /// </summary>
        public RouteSectionHandler()
            : base(null)
        {
        }


        #region IConfigurationSectionHandler Members

        /// <summary>
        /// Método chamado pelo .NET passando as informações sobre a sessão
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="configContext"></param>
        /// <param name="section"></param>
        /// <returns></returns>
        public object Create(object parent, object configContext, XmlNode section)
        {
            root = section;
            return this;
        }

        #endregion
    }
}
