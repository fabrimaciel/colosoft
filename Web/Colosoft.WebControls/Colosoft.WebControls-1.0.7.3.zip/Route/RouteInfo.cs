﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Colosoft.WebControls.Route
{
    /// <summary>
    /// Armazena as informações da rota.
    /// </summary>
    public class RouteInfo
    {
        #region Variáveis Locais

        private string _name;

        private string _location;

        private string _path;

        private string _destinationPage;

        private bool _isCompiled = true;

        private string _actionName;

        private bool _isDirectory = false;

        private bool _isSecurePage = false;

        private bool _forceNoSecurePage = false;


        #endregion

        #region Propriedades

        /// <summary>
        /// Nome do roteamento.
        /// </summary>
        public string Name
        {
            get { return _name; }
            internal set { _name = value; }
        }

        /// <summary>
        /// Localização que ativa o roteamento.
        /// </summary>
        public string Location
        {
            get { return _location; }
            internal set { _location = value; }
        }

        /// <summary>
        /// Informações do path aceito pelo roteamento.
        /// </summary>
        public string Path
        {
            get { return _path; }
            internal set { _path = value; }
        }

        /// <summary>
        /// Página de destino do roteamento.
        /// </summary>
        public string DestinationPage
        {
            get { return _destinationPage; }
            internal set { _destinationPage = value; }
        }

        /// <summary>
        /// Determina que o conteúdo é compilado.
        /// </summary>
        public bool Compiled
        {
            get { return _isCompiled; }
            internal set { _isCompiled = value; }
        }

        /// <summary>
        /// Nome da ação relacionada.
        /// </summary>
        public string ActionName
        {
            get { return _actionName; }
            internal set { _actionName = value; }
        }

        /// <summary>
        /// Identifica se o roteamento é para um diretório.
        /// </summary>
        public bool IsDirectory
        {
            get { return _isDirectory; }
            set { _isDirectory = value; }
        }

        /// <summary>
        /// Identifica que a página exige segurança.
        /// </summary>
        public bool IsSecurePage
        {
            get { return _isSecurePage; }
            set { _isSecurePage = value; }
        }

        /// <summary>
        /// Força a rota não atender páginas de segurança.
        /// </summary>
        public bool ForceNoSecurePage
        {
            get { return _forceNoSecurePage; }
            set { _forceNoSecurePage = value; }
        }

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor padrao.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="location"></param>
        /// <param name="destinationPage"></param>
        /// <param name="path"></param>
        /// <param name="compiled"></param>
        /// <param name="actionName"></param>
        /// <param name="isDirectory">Identifica que o roteamento é para um diretório.</param>
        /// <param name="isSecurePage"></param>
        /// <param name="forceNoSecurePage"></param>
        public RouteInfo(string name, string location, string destinationPage, 
                         string path, bool compiled, string actionName, bool isDirectory,
                         bool isSecurePage, bool forceNoSecurePage)
        {
            _name = name;
            _location = location;
            _destinationPage = destinationPage;
            _path = path;
            _isCompiled = compiled;            
            _actionName = actionName;
            _isDirectory = isDirectory;
            _isSecurePage = isSecurePage;
            _forceNoSecurePage = forceNoSecurePage;
            
        }

        #endregion

        #region Methods

        /// <summary>
        /// Método acionado quando inicia uma requisição para a rota.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        internal RouteActionBeginResponse BeginRequest(RouteActionBeginRequest request)
        {
            if (!string.IsNullOrEmpty(ActionName))
            {
                var action = RouteSettings.GetAction(ActionName);
                if (action != null)
                    return action.BeginRequest(this, request);
            }

            return null;
        }

        /// <summary>
        /// Método acionado quando a rota está sendo pré-carregada.
        /// </summary>
        internal RouteActionResponse PreLoad(RouteActionRequest request)
        {
            if (!string.IsNullOrEmpty(ActionName))
            {
                var action = RouteSettings.GetAction(ActionName);
                if (action != null)
                    return action.PreLoad(this, request);
            }

            return null;
        }

        /// <summary>
        /// Método acionado quando a rota for carregada.
        /// </summary>
        internal void Load()
        {
            if (!string.IsNullOrEmpty(ActionName))
            {
                var action = RouteSettings.GetAction(ActionName);
                if (action != null)
                    action.Load(this);
            }
        }

        #endregion
    }
}
