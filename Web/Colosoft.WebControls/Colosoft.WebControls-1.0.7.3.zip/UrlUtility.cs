﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Classe com métodos que auxiliam na manipulação de urls.
    /// </summary>
    public class UrlUtility
    {
        /// <summary>
        /// Recupera o nome do servidor de onde está sendo feita a requisição.
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static string GetUrlServerName(HttpContext context)
        {
            return context.Request.Url.AbsoluteUri.Substring(0, context.Request.Url.AbsoluteUri.Length - context.Request.RawUrl.Length);
        }

        /// <summary>
        /// Extrai a url virtual.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string ExtractVirtualUrl(string url)
        {
            return ExtractVirtualUrl(url, HttpContext.Current);
        }

        /// <summary>
        /// Extrai a url virtual.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public static string ExtractVirtualUrl(string url, HttpContext context)
        {
            if (!string.IsNullOrEmpty(url))
            {
                string urlServer = GetUrlServerName(context);

                if (url.IndexOf(urlServer) != 0)
                    return url;

                // Localiza o fim da http:// ou https://
                int pos = url.IndexOf("://");

                if (pos >= 0)
                {
                    pos += 3;

                    pos = url.IndexOf('/', pos);

                    url = url.Substring(pos + 1);

                    string[] parts = url.Split('/');

                    // Get ApplicationPath
                    string appPath = context.Request.ApplicationPath.Substring(1);

                    for (int i = 0; i < parts.Length; i++)
                    {
                        if (string.Compare(appPath, parts[i], true) == 0)
                        {
                            url = "~/";
                            for (int j = i + 1; j < parts.Length; j++)
                                url += parts[j] + ((j + 1) < parts.Length ? "/" : "");

                            break;
                        }
                    }
                }
            }

            return url;
        }
    }
}
