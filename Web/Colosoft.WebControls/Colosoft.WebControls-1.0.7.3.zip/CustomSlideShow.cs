﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;
using System.Security.Permissions;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Representa um controle de slide customizado.
    /// </summary>
    [ParseChildren(true, "Items"),
    AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal),
    AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal),
    ToolboxData("<{0}:CustomSlideShow runat=\"server\"> </{0}:CustomSlideShow>")]
    public class CustomSlideShow : WebControl
    {
        #region Properties

        protected override HtmlTextWriterTag TagKey
        {
            get
            {
                return HtmlTextWriterTag.Div;
            }
        }

        #endregion
    }
}
