﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web;
using System.Security.Permissions;
using System.ComponentModel;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Descreve os dados do item do slideshow.
    /// </summary>
    [System.ComponentModel.TypeConverter(typeof(System.ComponentModel.ExpandableObjectConverter)), 
    ParseChildren(true, "Description"), 
    AspNetHostingPermission(SecurityAction.LinkDemand, Level=AspNetHostingPermissionLevel.Minimal)]
    public class SlideShowItem
    {
        #region Variaveis Locais

        private string _imageUrl;
        private string _title;
        private string _description;
        private string _navigateUrl;
        //private bool _enabled = true;

        #endregion

        #region Propriedades

        /// <summary>
        /// Url da imagem do item.
        /// </summary>
        [Category("Navigate"),
        PersistenceMode(PersistenceMode.Attribute),
        DefaultValue("")]
        public string ImageUrl
        {
            get { return _imageUrl; }
            set { _imageUrl = value; }
        }

        /// <summary>
        /// Titulo do item.
        /// </summary>
        [Category("Behavior"),
        PersistenceMode(PersistenceMode.Attribute),
        DefaultValue("")]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        /// <summary>
        /// Descricao do item.
        /// </summary>
        [System.ComponentModel.Localizable(true), 
        PersistenceMode(PersistenceMode.InnerDefaultProperty),
        Category("Behavior"),
        DefaultValue("")]
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        /// <summary>
        /// Url de navegacao do item.
        /// </summary>
        [Category("Navigate"),
        PersistenceMode(PersistenceMode.Attribute),
        DefaultValue("")]
        public string NavigateUrl
        {
            get { return _navigateUrl; }
            set { _navigateUrl = value; }
        }

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor padrao.
        /// </summary>
        public SlideShowItem()
            : this("", "", "", "")
        {

        }

        public SlideShowItem(string imageUrl)
            : this("", "", imageUrl, "")
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="title">Titulo do item.</param>
        /// <param name="description">Descricao do item.</param>
        /// <param name="imageUrl">Url da imagem do item.</param>
        public SlideShowItem(string title, string description, string imageUrl)
            : this(title, description, imageUrl, "")
        {

        }

        /// <param name="title">Titulo do item.</param>
        /// <param name="description">Descricao do item.</param>
        /// <param name="imageUrl">Url da imagem do item.</param>
        /// <param name="navigateUrl">Url de navegacao.</param>
        public SlideShowItem(string title, string description, string imageUrl, string navigateUrl)
        {
            _title = title;
            _description = description;
            _imageUrl = imageUrl;
            _navigateUrl = navigateUrl;
        }

        #endregion
    }
}
