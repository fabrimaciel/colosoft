﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Security.Permissions;
using System.Web.UI;

namespace Colosoft.WebControls
{
    /// <summary>
    /// Representa as informações de um item basico.
    /// </summary>
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal), 
     AspNetHostingPermission(SecurityAction.InheritanceDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public class BaseItem : IStateManager, INamingContainer
    {
        #region Local Variables

        //private object _dataItem;
        private bool _isTrackingViewState;
        private StateBag _statebag  = new StateBag();

        #endregion

        #region Protecteds Methods

        /// <summary>
        /// Recupera os dados do ViewState.
        /// </summary>
        /// <param name="savedState"></param>
        protected virtual void LoadViewState(object savedState)
        {
            object[] objArray = (object[])savedState;
            if (objArray.Length != 1)
            {
                throw new ArgumentException("Invalid View State");
            }
            ((IStateManager)this.ViewState).LoadViewState(objArray[0]);
        }

        /// <summary>
        /// Salva os dados do ViewState.
        /// </summary>
        /// <returns></returns>
        protected virtual object SaveViewState()
        {
            object[] objArray = new object[1];
            if (this.ViewState != null)
            {
                objArray[0] = ((IStateManager)this.ViewState).SaveViewState();
            }
            return objArray;
        }

        protected virtual void TrackViewState()
        {
            _isTrackingViewState = true;
            if (this.ViewState != null)
            {
                ((IStateManager)this.ViewState).TrackViewState();
            }
        }


        /// <summary>
        /// Marca a instancia como suja.
        /// </summary>
        internal void SetDirty()
        {
            ViewState.SetDirty(true);
        }

        #endregion

        #region Members Of IStateManager

        void IStateManager.LoadViewState(object state)
        {
            this.LoadViewState(state);
        }

        object IStateManager.SaveViewState()
        {
            return this.SaveViewState();
        }

        void IStateManager.TrackViewState()
        {
            this.TrackViewState();
        }

        #endregion

        #region Properties

        protected virtual bool IsTrackingViewState
        {
            get
            {
                return _isTrackingViewState;
            }
        }

        bool IStateManager.IsTrackingViewState
        {
            get
            {
                return this.IsTrackingViewState;
            }
        }

        protected StateBag ViewState
        {
            get
            {
                return this._statebag;
            }
        }

        #endregion

    }
}
